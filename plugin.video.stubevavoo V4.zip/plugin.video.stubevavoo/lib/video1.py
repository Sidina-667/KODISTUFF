import base64, codecs
stube = 'aW1wb3J0IHZpZGVvDQp2aWRlby5tYWluKCk='
trust = eval('stube')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
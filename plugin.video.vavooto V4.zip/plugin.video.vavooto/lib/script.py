# Embedded file name: ./lib/script.py
import sys
import xbmc
import xbmcgui
import xbmcaddon
import utils

def main():
    params = {}
    for arg in sys.argv[1:]:
        key, value = arg.split('=', 1)
        params[key] = value

    try:
        action = params.get('action', '').lower()
        if action == 'dialogok':
            dialogOk(params)
        elif action == 'dialogyesno':
            dialogYesNo(params)
        elif action == 'dialogdonate':
            dialogDonate(params)
        elif action == 'dialogwhatsapp':
            dialogOk(params)
        elif action == 'iptvsimple':
            iptvsimple = xbmcaddon.Addon('pvr.iptvsimple')
            iptvsimple.openSettings()
        elif action == 'urlresolver':
            urlresolver = xbmcaddon.Addon('script.module.urlresolver')
            urlresolver.openSettings()
            xbmc.executebuiltin('ActivateWindow(Settings)')
        elif action == 'report':
            import vjackson
            vjackson.report(params)
        elif action == 'download/add':
            import dldb
            dldb.downloadAdd(params)
        elif action == 'download/force':
            import dldb
            dldb.downloadForce(params)
        elif action == 'download/delete':
            import dldb
            dldb.downloadDelete(params)
        elif action == 'download/active':
            import dldb
            dldb.downloadActive(params)
        elif action == 'download/pausetoggle':
            import dldb
            dldb.downloadPauseToggle(params)
        else:
            raise Exception('Unknown action: %r' % params)
    except Exception as e:
        import traceback
        traceback.print_exc()
        import reporterror
        reporterror.report(utils.addonID, e, params)
        raise e


def executeIfSet(action):
    if action:
        xbmc.executebuiltin(action)


def dialogOk(params):
    xbmcgui.Dialog().ok(heading=params.get('heading', None), line1=params.get('line1', None), line2=params.get('line2', None), line3=params.get('line3', None))
    executeIfSet(params.get('script'))
    return


def dialogYesNo(params):
    result = xbmcgui.Dialog().yesno(heading=params.get('heading', None), line1=params.get('line1', None), line2=params.get('line2', None), line3=params.get('line3', None), nolabel=params.get('nolabel', None), yeslabel=params.get('yeslabel', None), autoclose=params.get('autoclose', 0))
    if result:
        executeIfSet(params.get('yesaction'))
    else:
        executeIfSet(params.get('noaction'))
    return


def dialogDonate(params):
    window = xbmcgui.WindowXML('custom-Donate.xml', xbmcaddon.Addon().getAddonInfo('path').decode('utf-8'), 'default', '720p')
    window.setProperty('BTC', '1HBYPiagAYtjapUfRyEHLvQpodbxvtoQ1t')
    window.doModal()
    del window


if __name__ == '__main__':
    main()
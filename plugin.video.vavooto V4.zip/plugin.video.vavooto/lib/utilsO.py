# Embedded file name: ./lib/utils.py
import re
import threading
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import xbmc
import os
import sqlite3
import time
import json
import zlib
from contextlib import contextmanager
addonID = 'plugin.video.vavooto'
addon = xbmcaddon.Addon(addonID)

class Thread(threading.Thread):

    def __init__(self, target, *args):
        self._target = target
        self._args = args
        threading.Thread.__init__(self)

    def run(self):
        self._target(*self._args)


def replaceHTMLCodes(txt):
    import HTMLParser
    txt = re.sub('(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', txt)
    txt = HTMLParser.HTMLParser().unescape(txt)
    txt = txt.replace('&quot;', '"')
    txt = txt.replace('&amp;', '&')
    txt = txt.strip()
    return txt


def getPluginhandle():
    return int(sys.argv[1])


def addDir(name, url, iconimage, isPlayable = False):
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name})
    if isPlayable:
        liz.setProperty('IsPlayable', 'true')
    isFolder = False if isPlayable else True
    ok = xbmcplugin.addDirectoryItem(handle=getPluginhandle(), url=url, listitem=liz, isFolder=isFolder)
    return ok


class Database(object):

    def __init__(self, basePath = None, filename = None):
        self.conn = None
        if basePath is None:
            basePath = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
        self.basePath = basePath
        self.path = os.path.join(basePath, filename)
        return

    def getConnection(self):
        if not self.conn:
            self.conn = self.onNewConnection()
        return self.conn

    def onNewConnection(self):
        if not os.path.exists(self.basePath):
            os.makedirs(self.basePath)
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def cursor(self):
        return self.getConnection().cursor()

    def commit(self):
        self.getConnection().commit()

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None
        return

    @contextmanager
    def singleConnectionCursor(self):
        conn = self.onNewConnection()
        try:
            cursor = conn.cursor()
            try:
                yield cursor
                conn.commit()
            finally:
                cursor.close()

        finally:
            conn.close()


class SCache(object):
    db = Database(filename='cache.db')
    isClassInitialized = False

    def __init__(self, name, timeout):
        self.name = name
        self.timeout = timeout
        self.isInitialized = False

    @classmethod
    def _initClass(cls):
        if cls.isClassInitialized:
            return
        with cls.db.singleConnectionCursor() as c:
            c.execute('CREATE TABLE IF NOT EXISTS cache (created INTEGER,name VARCHARR(100) NOT NULL,key VARCHARR(1000) NOT NULL,data TEXT)')
        cls.isClassInitialized = True

    def _initObject(self):
        if self.isInitialized:
            return
        self.__class__._initClass()
        with self.__class__.db.singleConnectionCursor() as c:
            c.execute('DELETE FROM cache WHERE name=? AND created<?', [self.name, int(time.time() - self.timeout)])
        self.isInitialized = True

    def get(self, key):
        self._initObject()
        with self.__class__.db.singleConnectionCursor() as c:
            c.execute('SELECT data FROM cache WHERE name=? AND key=?', [self.name, key])
            data = c.fetchone()
        if not data:
            return
        else:
            return json.loads(zlib.decompress(data[0].decode('base64')))

    def set(self, key, data):
        self._initObject()
        data = zlib.compress(json.dumps(data)).encode('base64')
        with self.__class__.db.singleConnectionCursor() as c:
            c.execute('INSERT INTO cache (name, key, data, created) VALUES (?, ?, ?, ?)', [self.name,
             key,
             data,
             int(time.time())])

    def delete(self, key):
        self._initObject()
        with self.__class__.db.singleConnectionCursor() as c:
            c.execute('DELETE FROM cache WHERE name=? AND key=?', [self.name, key])


cache = {'short': SCache('short', 300),
 'medium': SCache('medium', 1800),
 'long': SCache('long', 10800)}
# Embedded file name: ./lib/websocket/_exceptions.py


class WebSocketException(Exception):
    pass


class WebSocketProtocolException(WebSocketException):
    pass


class WebSocketPayloadException(WebSocketException):
    pass


class WebSocketConnectionClosedException(WebSocketException):
    pass


class WebSocketTimeoutException(WebSocketException):
    pass


class WebSocketProxyException(WebSocketException):
    pass


class WebSocketBadStatusException(WebSocketException):

    def __init__(self, message, status_code):
        super(WebSocketBadStatusException, self).__init__(message % status_code)
        self.status_code = status_code
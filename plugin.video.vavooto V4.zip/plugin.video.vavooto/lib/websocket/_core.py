# Embedded file name: ./lib/websocket/_core.py
from __future__ import print_function
import socket
import struct
import threading
import six
from ._abnf import *
from ._exceptions import *
from ._handshake import *
from ._http import *
from ._logging import *
from ._socket import *
from ._utils import *
__all__ = ['WebSocket', 'create_connection']

class WebSocket(object):

    def __init__(self, get_mask_key = None, sockopt = None, sslopt = None, fire_cont_frame = False, enable_multithread = False, skip_utf8_validation = False, **_):
        self.sock_opt = sock_opt(sockopt, sslopt)
        self.handshake_response = None
        self.sock = None
        self.connected = False
        self.get_mask_key = get_mask_key
        self.frame_buffer = frame_buffer(self._recv, skip_utf8_validation)
        self.cont_frame = continuous_frame(fire_cont_frame, skip_utf8_validation)
        if enable_multithread:
            self.lock = threading.Lock()
        else:
            self.lock = NoLock()
        return

    def __iter__(self):
        while True:
            yield self.recv()

    def __next__(self):
        return self.recv()

    def next(self):
        return self.__next__()

    def fileno(self):
        return self.sock.fileno()

    def set_mask_key(self, func):
        self.get_mask_key = func

    def gettimeout(self):
        return self.sock_opt.timeout

    def settimeout(self, timeout):
        self.sock_opt.timeout = timeout
        if self.sock:
            self.sock.settimeout(timeout)

    timeout = property(gettimeout, settimeout)

    def getsubprotocol(self):
        if self.handshake_response:
            return self.handshake_response.subprotocol
        else:
            return None
            return None

    subprotocol = property(getsubprotocol)

    def getstatus(self):
        if self.handshake_response:
            return self.handshake_response.status
        else:
            return None
            return None

    status = property(getstatus)

    def getheaders(self):
        if self.handshake_response:
            return self.handshake_response.headers
        else:
            return None
            return None

    headers = property(getheaders)

    def connect(self, url, **options):
        self.sock, addrs = connect(url, self.sock_opt, proxy_info(**options), options.pop('socket', None))
        try:
            self.handshake_response = handshake(self.sock, *addrs, **options)
            self.connected = True
        except:
            if self.sock:
                self.sock.close()
                self.sock = None
            raise

        return

    def send(self, payload, opcode = ABNF.OPCODE_TEXT):
        frame = ABNF.create_frame(payload, opcode)
        return self.send_frame(frame)

    def send_frame(self, frame):
        if self.get_mask_key:
            frame.get_mask_key = self.get_mask_key
        data = frame.format()
        length = len(data)
        trace('send: ' + repr(data))
        with self.lock:
            while data:
                l = self._send(data)
                data = data[l:]

        return length

    def send_binary(self, payload):
        return self.send(payload, ABNF.OPCODE_BINARY)

    def ping(self, payload = ''):
        if isinstance(payload, six.text_type):
            payload = payload.encode('utf-8')
        self.send(payload, ABNF.OPCODE_PING)

    def pong(self, payload):
        if isinstance(payload, six.text_type):
            payload = payload.encode('utf-8')
        self.send(payload, ABNF.OPCODE_PONG)

    def recv(self):
        opcode, data = self.recv_data()
        if six.PY3 and opcode == ABNF.OPCODE_TEXT:
            return data.decode('utf-8')
        elif opcode == ABNF.OPCODE_TEXT or opcode == ABNF.OPCODE_BINARY:
            return data
        else:
            return ''

    def recv_data(self, control_frame = False):
        opcode, frame = self.recv_data_frame(control_frame)
        return (opcode, frame.data)

    def recv_data_frame(self, control_frame = False):
        while True:
            frame = self.recv_frame()
            if not frame:
                raise WebSocketProtocolException('Not a valid frame %s' % frame)
            elif frame.opcode in (ABNF.OPCODE_TEXT, ABNF.OPCODE_BINARY, ABNF.OPCODE_CONT):
                self.cont_frame.validate(frame)
                self.cont_frame.add(frame)
                if self.cont_frame.is_fire(frame):
                    return self.cont_frame.extract(frame)
            else:
                if frame.opcode == ABNF.OPCODE_CLOSE:
                    self.send_close()
                    return (frame.opcode, frame)
                if frame.opcode == ABNF.OPCODE_PING:
                    if len(frame.data) < 126:
                        self.pong(frame.data)
                    else:
                        raise WebSocketProtocolException('Ping message is too long')
                    if control_frame:
                        return (frame.opcode, frame)
                elif frame.opcode == ABNF.OPCODE_PONG:
                    if control_frame:
                        return (frame.opcode, frame)

    def recv_frame(self):
        return self.frame_buffer.recv_frame()

    def send_close(self, status = STATUS_NORMAL, reason = six.b('')):
        if status < 0 or status >= ABNF.LENGTH_16:
            raise ValueError('code is invalid range')
        self.connected = False
        self.send(struct.pack('!H', status) + reason, ABNF.OPCODE_CLOSE)

    def close(self, status = STATUS_NORMAL, reason = six.b(''), timeout = 3):
        if self.connected:
            if status < 0 or status >= ABNF.LENGTH_16:
                raise ValueError('code is invalid range')
            try:
                self.connected = False
                self.send(struct.pack('!H', status) + reason, ABNF.OPCODE_CLOSE)
                sock_timeout = self.sock.gettimeout()
                self.sock.settimeout(timeout)
                try:
                    frame = self.recv_frame()
                    if isEnabledForError():
                        recv_status = struct.unpack('!H', frame.data)[0]
                        if recv_status != STATUS_NORMAL:
                            error('close status: ' + repr(recv_status))
                except:
                    pass

                self.sock.settimeout(sock_timeout)
                self.sock.shutdown(socket.SHUT_RDWR)
            except:
                pass

        self.shutdown()

    def abort(self):
        if self.connected:
            self.sock.shutdown(socket.SHUT_RDWR)

    def shutdown(self):
        if self.sock:
            self.sock.close()
            self.sock = None
            self.connected = False
        return

    def _send(self, data):
        return send(self.sock, data)

    def _recv(self, bufsize):
        try:
            return recv(self.sock, bufsize)
        except WebSocketConnectionClosedException:
            if self.sock:
                self.sock.close()
            self.sock = None
            self.connected = False
            raise

        return


def create_connection(url, timeout = None, class_ = WebSocket, **options):
    sockopt = options.pop('sockopt', [])
    sslopt = options.pop('sslopt', {})
    fire_cont_frame = options.pop('fire_cont_frame', False)
    enable_multithread = options.pop('enable_multithread', False)
    skip_utf8_validation = options.pop('skip_utf8_validation', False)
    websock = class_(sockopt=sockopt, sslopt=sslopt, fire_cont_frame=fire_cont_frame, enable_multithread=enable_multithread, skip_utf8_validation=skip_utf8_validation, **options)
    websock.settimeout(timeout if timeout is not None else getdefaulttimeout())
    websock.connect(url, **options)
    return websock
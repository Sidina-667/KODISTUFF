# Embedded file name: ./lib/websocket/_app.py
import select
import sys
import threading
import time
import traceback
import six
from ._abnf import ABNF
from ._core import WebSocket, getdefaulttimeout
from ._exceptions import *
from ._logging import *
__all__ = ['WebSocketApp']

class WebSocketApp(object):

    def __init__(self, url, header = None, on_open = None, on_message = None, on_error = None, on_close = None, on_ping = None, on_pong = None, on_cont_message = None, keep_running = True, get_mask_key = None, cookie = None, subprotocols = None, on_data = None):
        self.url = url
        self.header = header if header is not None else []
        self.cookie = cookie
        self.on_open = on_open
        self.on_message = on_message
        self.on_data = on_data
        self.on_error = on_error
        self.on_close = on_close
        self.on_ping = on_ping
        self.on_pong = on_pong
        self.on_cont_message = on_cont_message
        self.keep_running = keep_running
        self.get_mask_key = get_mask_key
        self.sock = None
        self.last_ping_tm = 0
        self.last_pong_tm = 0
        self.subprotocols = subprotocols
        return

    def send(self, data, opcode = ABNF.OPCODE_TEXT):
        if not self.sock or self.sock.send(data, opcode) == 0:
            raise WebSocketConnectionClosedException('Connection is already closed.')

    def close(self, **kwargs):
        self.keep_running = False
        if self.sock:
            self.sock.close(**kwargs)

    def _send_ping(self, interval, event):
        while not event.wait(interval):
            self.last_ping_tm = time.time()
            if self.sock:
                try:
                    self.sock.ping()
                except Exception as ex:
                    warning('send_ping routine terminated: {}'.format(ex))
                    break

    def run_forever(self, sockopt = None, sslopt = None, ping_interval = 0, ping_timeout = None, http_proxy_host = None, http_proxy_port = None, http_no_proxy = None, http_proxy_auth = None, skip_utf8_validation = False, host = None, origin = None):
        if not ping_timeout or ping_timeout <= 0:
            ping_timeout = None
        if ping_timeout and ping_interval and ping_interval <= ping_timeout:
            raise WebSocketException('Ensure ping_interval > ping_timeout')
        if sockopt is None:
            sockopt = []
        if sslopt is None:
            sslopt = {}
        if self.sock:
            raise WebSocketException('socket is already opened')
        thread = None
        close_frame = None
        try:
            self.sock = WebSocket(self.get_mask_key, sockopt=sockopt, sslopt=sslopt, fire_cont_frame=self.on_cont_message and True or False, skip_utf8_validation=skip_utf8_validation)
            self.sock.settimeout(getdefaulttimeout())
            self.sock.connect(self.url, header=self.header, cookie=self.cookie, http_proxy_host=http_proxy_host, http_proxy_port=http_proxy_port, http_no_proxy=http_no_proxy, http_proxy_auth=http_proxy_auth, subprotocols=self.subprotocols, host=host, origin=origin)
            self._callback(self.on_open)
            if ping_interval:
                event = threading.Event()
                thread = threading.Thread(target=self._send_ping, args=(ping_interval, event))
                thread.setDaemon(True)
                thread.start()
            while self.sock.connected:
                r, w, e = select.select((self.sock.sock,), (), (), ping_timeout)
                if not self.keep_running:
                    break
                if r:
                    op_code, frame = self.sock.recv_data_frame(True)
                    if op_code == ABNF.OPCODE_CLOSE:
                        close_frame = frame
                        break
                    elif op_code == ABNF.OPCODE_PING:
                        self._callback(self.on_ping, frame.data)
                    elif op_code == ABNF.OPCODE_PONG:
                        self.last_pong_tm = time.time()
                        self._callback(self.on_pong, frame.data)
                    elif op_code == ABNF.OPCODE_CONT and self.on_cont_message:
                        self._callback(self.on_data, data, frame.opcode, frame.fin)
                        self._callback(self.on_cont_message, frame.data, frame.fin)
                    else:
                        data = frame.data
                        if six.PY3 and opcode == ABNF.OPCODE_TEXT:
                            data = data.decode('utf-8')
                        self._callback(self.on_data, data, frame.opcode, True)
                        self._callback(self.on_message, data)
                if ping_timeout and self.last_ping_tm and time.time() - self.last_ping_tm > ping_timeout and self.last_ping_tm - self.last_pong_tm > ping_timeout:
                    raise WebSocketTimeoutException('ping/pong timed out')

        except (Exception, KeyboardInterrupt, SystemExit) as e:
            self._callback(self.on_error, e)
            if isinstance(e, SystemExit):
                raise
        finally:
            if thread and thread.isAlive():
                event.set()
                thread.join()
                self.keep_running = False
            self.sock.close()
            close_args = self._get_close_args(close_frame.data if close_frame else None)
            self._callback(self.on_close, *close_args)
            self.sock = None

        return

    def _get_close_args(self, data):
        import inspect
        if sys.version_info < (3, 0):
            if not self.on_close or len(inspect.getargspec(self.on_close).args) != 3:
                return []
        elif not self.on_close or len(inspect.getfullargspec(self.on_close).args) != 3:
            return []
        if data and len(data) >= 2:
            code = 256 * six.byte2int(data[0:1]) + six.byte2int(data[1:2])
            reason = data[2:].decode('utf-8')
            return [code, reason]
        else:
            return [None, None]

    def _callback(self, callback, *args):
        if callback:
            try:
                callback(self, *args)
            except Exception as e:
                error('error from callback {}: {}'.format(callback, e))
                if isEnabledForDebug():
                    _, _, tb = sys.exc_info()
                    traceback.print_tb(tb)
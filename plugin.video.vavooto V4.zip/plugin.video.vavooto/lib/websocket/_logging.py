# Embedded file name: ./lib/websocket/_logging.py
import logging
_logger = logging.getLogger('websocket')
_traceEnabled = False
__all__ = ['enableTrace',
 'dump',
 'error',
 'debug',
 'trace',
 'isEnabledForError',
 'isEnabledForDebug']

def enableTrace(traceable):
    global _traceEnabled
    _traceEnabled = traceable
    if traceable:
        if not _logger.handlers:
            _logger.addHandler(logging.StreamHandler())
        _logger.setLevel(logging.DEBUG)


def dump(title, message):
    if _traceEnabled:
        _logger.debug('--- ' + title + ' ---')
        _logger.debug(message)
        _logger.debug('-----------------------')


def error(msg):
    _logger.error(msg)


def warning(msg):
    _logger.warning(msg)


def debug(msg):
    _logger.debug(msg)


def trace(msg):
    if _traceEnabled:
        _logger.debug(msg)


def isEnabledForError():
    return _logger.isEnabledFor(logging.ERROR)


def isEnabledForDebug():
    return _logger.isEnabledFor(logging.DEBUG)
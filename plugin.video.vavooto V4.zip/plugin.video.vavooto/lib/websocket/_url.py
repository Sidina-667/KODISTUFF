# Embedded file name: ./lib/websocket/_url.py
import os
import socket
import struct
from six.moves.urllib.parse import urlparse
__all__ = ['parse_url', 'get_proxy_info']

def parse_url(url):
    if ':' not in url:
        raise ValueError('url is invalid')
    scheme, url = url.split(':', 1)
    parsed = urlparse(url, scheme='ws')
    if parsed.hostname:
        hostname = parsed.hostname
    else:
        raise ValueError('hostname is invalid')
    port = 0
    if parsed.port:
        port = parsed.port
    is_secure = False
    if scheme == 'ws':
        if not port:
            port = 80
    elif scheme == 'wss':
        is_secure = True
        if not port:
            port = 443
    else:
        raise ValueError('scheme %s is invalid' % scheme)
    if parsed.path:
        resource = parsed.path
    else:
        resource = '/'
    if parsed.query:
        resource += '?' + parsed.query
    return (hostname,
     port,
     resource,
     is_secure)


DEFAULT_NO_PROXY_HOST = ['localhost', '127.0.0.1']

def _is_ip_address(addr):
    try:
        socket.inet_aton(addr)
    except socket.error:
        return False

    return True


def _is_subnet_address(hostname):
    try:
        addr, netmask = hostname.split('/')
        return _is_ip_address(addr) and 0 <= int(netmask) < 32
    except ValueError:
        return False


def _is_address_in_network(ip, net):
    ipaddr = struct.unpack('I', socket.inet_aton(ip))[0]
    netaddr, bits = net.split('/')
    netmask = struct.unpack('I', socket.inet_aton(netaddr))[0] & (2 << int(bits) - 1) - 1
    return ipaddr & netmask == netmask


def _is_no_proxy_host(hostname, no_proxy):
    if not no_proxy:
        v = os.environ.get('no_proxy', '').replace(' ', '')
        no_proxy = v.split(',')
    if not no_proxy:
        no_proxy = DEFAULT_NO_PROXY_HOST
    if hostname in no_proxy:
        return True
    if _is_ip_address(hostname):
        return any([ _is_address_in_network(hostname, subnet) for subnet in no_proxy if _is_subnet_address(subnet) ])
    return False


def get_proxy_info(hostname, is_secure, proxy_host = None, proxy_port = 0, proxy_auth = None, no_proxy = None):
    if _is_no_proxy_host(hostname, no_proxy):
        return (None, 0, None)
    elif proxy_host:
        port = proxy_port
        auth = proxy_auth
        return (proxy_host, port, auth)
    else:
        env_keys = ['http_proxy']
        if is_secure:
            env_keys.insert(0, 'https_proxy')
        for key in env_keys:
            value = os.environ.get(key, None)
            if value:
                proxy = urlparse(value)
                auth = (proxy.username, proxy.password) if proxy.username else None
                return (proxy.hostname, proxy.port, auth)

        return (None, 0, None)
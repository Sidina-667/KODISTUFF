# Embedded file name: ./lib/websocket/_ssl_compat.py
__all__ = ['HAVE_SSL', 'ssl', 'SSLError']
try:
    import ssl
    from ssl import SSLError
    if hasattr(ssl, 'SSLContext') and hasattr(ssl.SSLContext, 'check_hostname'):
        HAVE_CONTEXT_CHECK_HOSTNAME = True
    else:
        HAVE_CONTEXT_CHECK_HOSTNAME = False
        if hasattr(ssl, 'match_hostname'):
            from ssl import match_hostname
        else:
            from backports.ssl_match_hostname import match_hostname
        __all__.append('match_hostname')
    __all__.append('HAVE_CONTEXT_CHECK_HOSTNAME')
    HAVE_SSL = True
except ImportError:

    class SSLError(Exception):
        pass


    HAVE_SSL = False
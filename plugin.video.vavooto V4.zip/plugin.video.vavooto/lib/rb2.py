# Embedded file name: ./lib/rb2.py
import websocket
import json
import uuid
import requests
import logging
import threading
import socket
import base64
logging.basicConfig(level=logging.INFO)

def spawn_thread(func, *args, **kwargs):

    class Thread(threading.Thread):

        def run(self):
            func(*args, **kwargs)

    t = Thread()
    t.setDaemon(True)
    t.start()


def print_log(*args):
    print ' '.join(map(str, args))


def resolve(host, url, request_timeout = 15):
    channels = {}
    functions = {}

    def add_channel(channel):

        def func(fn):
            channels[channel] = fn

        return func

    def remove_channel(channel):
        del channels[channel]

    def add_function(name):

        def func(fn):
            functions[name] = fn

        return func

    def send_to_channel(channel, data):
        ws.send(json.dumps({'channel': channel,
         'data': data}))

    def ws_on_message(ws, message):
        data = json.loads(message)
        channel = data['channel']
        data = data['data']
        channels[channel](data)

    def ws_on_error(ws, error):
        if not ws.result:
            import traceback
            traceback.print_exc()
            ws.result = RuntimeError('Socket error: %r' % error)

    def ws_on_close(ws):
        if not ws.result:
            ws.result = RuntimeError('Closed')

    def ws_on_open(ws):
        channel = 'resolve-' + str(uuid.uuid4())

        @add_channel(channel)
        def func(data):
            try:
                fn = data.pop('fn')
                functions[fn](channel, data)
            except Exception:
                import traceback
                traceback.print_exc()

        send_to_channel('resolve', {'responseChannel': channel,
         'requestTimeout': request_timeout,
         'url': url})

    @add_function('request')
    def fn_request(channel, data):

        def requester():
            try:
                options = {}
                if data['options'] and data['options']['proxy']:
                    options['proxies'] = {'http': data['options']['proxy'],
                     'https': data['options']['proxy']}
                resp = requests.request(method=data['method'], url=data['url'], headers=data['headers'], data=(base64.b64decode(data['postData']) if data['postData'] else None), allow_redirects=False, **options)
                print_log(channel, 'request', data['method'], data['url'], resp.status_code, len(resp.content), 'bytes')
                send_to_channel(data['responseChannel'], {'status': resp.status_code,
                 'headers': dict(resp.headers),
                 'body': base64.b64encode(resp.content) if resp.content else None})
            except requests.ConnectionError:
                send_to_channel(data['responseChannel'], {'status': 0,
                 'headers': dict(),
                 'body': base64.b64encode('Connection error')})
            except Exception:
                import traceback
                traceback.print_exc()

            return

        print_log(channel, 'request', data['method'], data['url'])
        spawn_thread(requester)

    @add_function('connect')
    def fn_connect(channel, data):

        def connecter(ctx):
            responseChannel = data['responseChannel']

            def my_send_to_channel(fn, **data):
                print_log(responseChannel, '<<', fn)
                send_to_channel(responseChannel, dict(fn=fn, **data))

            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.connect((data['hostname'], data['port']))
                if data['head']:
                    sock.sendall(base64.b64encode(data['head']))

                @add_channel(responseChannel)
                def message(data):
                    print_log(responseChannel, '>>', data['fn'])
                    if data['fn'] == 'data':
                        sock.sendall(base64.b64encode(data['data']))
                    elif data['fn'] == 'error' or data['fn'] == 'close':
                        ctx['running'] = False
                        sock.close()

                try:
                    my_send_to_channel('connected')
                    while ctx['running']:
                        chunk = sock.recv(32768)
                        if not chunk:
                            break
                        my_send_to_channel('data', data=base64.b64encode(chunk))

                finally:
                    remove_channel(responseChannel)

            except Exception as e:
                import traceback
                traceback.print_exc()
                my_send_to_channel('error', message=e.message)
            finally:
                sock.close()
                my_send_to_channel('close')

        print_log(channel, 'connect', data['hostname'], data['port'])
        spawn_thread(connecter, {'running': True})

    @add_function('resolved')
    def fn_resolved(channel, data):
        print_log(channel, 'resolved', data)
        ws.result = data
        ws.close()

    @add_function('error')
    def fn_error(channel, data):
        print_log(channel, 'error', data)
        ws.result = ValueError(data)
        ws.close()

    ws = websocket.WebSocketApp(host)
    ws.on_message = ws_on_message
    ws.on_error = ws_on_error
    ws.on_close = ws_on_close
    ws.on_open = ws_on_open
    ws.result = None
    ws.run_forever()
    return ws.result
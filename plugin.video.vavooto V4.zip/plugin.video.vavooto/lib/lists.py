# Embedded file name: ./lib/lists.py
import utils
import xbmc
import urllib2
import os
ACTIONS = {'kids': 'Kinder',
 'erotic': 'Erotik',
 'mediathek': 'Mediatheken', 'livetv': 'Livetv', 'kinokiste': 'Kinokiste', 'skyde': 'Skyde', 'serienkiste': 'Serienkiste', 'dokus': 'Dokus',  'pornbox': 'Pornbox'}

def kids(params):
    iconBase = 'special://home/addons/' + utils.addonID + '/resources/kids/'
    utils.addDir('Kinder TV', 'plugin://plugin.video.vavooto/?action=kidstv&group=Germany&type=channels', xbmc.translatePath(iconBase + 'kids.png'))
    utils.addDir('Kinderfilme', 'plugin://plugin.video.vavooto/?action=indexMovie&genre=Familie,Kinder,Jugend,Trickfilm&type=movie', xbmc.translatePath(iconBase + 'kids.png'))
    utils.addDir('Kinderserien', 'plugin://plugin.video.vavooto/?action=indexSerie&genre=Familie,Kinder,Kinderserie,Trickfilm&type=serie', xbmc.translatePath(iconBase + 'kids.png'))
    utils.addDir('Nick Junior', 'plugin://plugin.video.nick_de/?mode=nickJrMain', xbmc.translatePath(iconBase + 'kids.png'))
    utils.addDir('KidsTube', 'plugin://plugin.video.KidsTube', xbmc.translatePath(iconBase + 'kids.png'))
    utils.addDir('Kinderkino', 'plugin://plugin.video.netzkino_de/category/35/', xbmc.translatePath(iconBase + 'kids.png'))
    utils.addDir('Kindertube', 'plugin://plugin.program.super.favourites/?content_type&fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ffanart.jpg&image=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ficon.png&label=%5bCOLOR%20cyan%5dKINDERTUBE%5b%2fCOLOR%5d&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.super.favourites%2fSuper%20Favourites%2fKINDERTUBE', xbmc.translatePath(iconBase + 'kids.png'))


def livetv(params):
    iconBase = 'special://home/addons/' + utils.addonID + '/resources/livetv/'
    utils.addDir('STUBE TV', 'plugin://plugin.video.StubeTV/?fanart&mode=1&name=%5bB%5d%5bCOLOR%20red%5dStube%20%5bCOLOR%20skyblue%5dTV%20%20%5bCOLOR%20white%5d%20LiveTV%5b%2fCOLOR%5d%5b%2fB%5d%20&url=http%3a%2f%2frepo.stube.org%2ftvlist%2fmenu.xml', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('LIVE TV DE', 'plugin://plugin.video.vavooto/?action=channels&group=Germany&type=channels', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('SKY DEUTSCHLAND', 'plugin://plugin.video.vavooto/?action=skyde&group=Germany&type=channels', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('CINEMA TV DE', 'plugin://plugin.video.vavooto/?action=cinema&group=Germany&type=channels', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('KIDS TV DE', 'plugin://plugin.video.vavooto/?action=kidstv&group=Germany&type=channels', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('SPORTS TV WORLD', 'plugin://plugin.video.vavooto/?action=sport&type=channels', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('WORLD TV', 'plugin://plugin.video.vavooto/?action=channels&type=channels', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('FREE TV DE', 'plugin://plugin.video.wagasworld/?fanart&mode=1&name=GermanFreeTV%20%5bEXT%5d&url=https%3a%2f%2fbit.ly%2f2fxVnim', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('PSYCO TV', 'plugin://plugin.video.PsycoTV/?fanart&mode=1&name=%5bB%5d%5bCOLOR%20white%5dPsycoTV%20Portal%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fPsycoTV%2fPsycoTV%2fmaster%2ftv', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('ROBIN HOOD TV', 'plugin://plugin.video.PsycoTV/?fanart&mode=1&name=%5bCOLOR%20lime%5dRobinHood%5b%2fCOLOR%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fPsycoTV%2fPsycoTV%2fmaster%2frobinhood', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('PAVOO TV', 'plugin://plugin.video.PsycoTV/?fanart&mode=1&name=%5bCOLOR%20gold%5dPavoo%20TV%5b%2fCOLOR%5d&url=http%3a%2f%2fpavootv.com%2fPAVOOTV%2fmenu2.xml', xbmc.translatePath(iconBase + 'tv.png'))
    utils.addDir('VOODOO TV', 'plugin://plugin.program.super.favourites/?content_type&fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ffanart.jpg&image=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ficon.png&label=%5bCOLOR%20brown%5dVOODOTV%5b%2fCOLOR%5d&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.super.favourites%2fSuper%20Favourites%2fVOODOTV', xbmc.translatePath(iconBase + 'tv.png'))


def kinokiste(params):
    iconBase = 'special://home/addons/' + utils.addonID + '/resources/film/'
    utils.addDir('VAVOO FILME', 'plugin://plugin.video.vavooto/indexMovie?action=indexMovie&cancel=home', xbmc.translatePath(iconBase + 'vavoo.png'))
    utils.addDir('KINOKISTE', 'plugin://plugin.program.super.favourites/?content_type&fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ffanart.jpg&image=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ficon.png&label=%5bCOLOR%20azur%5dFILMBOX%5b%2fCOLOR%5d&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.super.favourites%2fSuper%20Favourites%2fFILMBOX', xbmc.translatePath(iconBase + 'film.png'))
    utils.addDir('WAGA MOVIES', 'plugin://plugin.video.wagasworld/?fanart=http%3a%2f%2fwagasworld.com%2fKodi%2fpic%2fmovies.png&mode=2&name=Movies&url=https%3a%2f%2fbit.ly%2f30N9p1k', xbmc.translatePath(iconBase + 'waga.png'))
    utils.addDir('PSYCO VOD I', 'plugin://plugin.video.RobinHoodTv/?fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.video.RobinHoodTv%2ffanart.jpg&mode=1&name=PsycoTV%20%5bB%5d%5bCOLORgreen%5dGerman%20VOD%201%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fghost-repo.de%2fGhost_Portal%2fGhostVOD%2ffilmedeutsch.txt', xbmc.translatePath(iconBase + 'psyco.png'))
    utils.addDir('PSYCO VOD II', 'plugin://plugin.video.RobinHoodTv/?fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.video.RobinHoodTv%2ffanart.jpg&mode=1&name=PsycoTV%20%5bB%5d%5bCOLORgreen%5dGerman%20VOD%202%5b%2fCOLOR%5d%5b%2fB%5d&url=http%3a%2f%2fghost-repo.de%2fGhost_Portal%2fGhostVOD%2fclassicfilme.txt', xbmc.translatePath(iconBase + 'psyco.png'))


def serienkiste(params):
    iconBase = 'special://home/addons/' + utils.addonID + '/resources/serie/'
    utils.addDir('VAVOO SERIEN', 'plugin://plugin.video.vavooto/?action=indexSerie&cancel=home', xbmc.translatePath(iconBase + 'vavoo.png'))
    utils.addDir('SERIENKISTE', 'plugin://plugin.program.super.favourites/?content_type&fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ffanart.jpg&image=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ficon.png&label=%5bCOLOR%20azur%5dSERIENBOX%5b%2fCOLOR%5d&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.super.favourites%2fSuper%20Favourites%2fSERIENBOX', xbmc.translatePath(iconBase + 'serienkiste.png'))
    utils.addDir('WAGA SITCOM', 'plugin://plugin.video.wagasworld/?fanart=http%3a%2f%2fwagasworld.com%2fKodi%2fpic%2fsitomthumb.jpg&mode=2&name=%5bCOLOR%20white%5dSitcom%5b%2fCOLOR%5d&url=https%3a%2f%2fbit.ly%2f30N9p1k', xbmc.translatePath(iconBase + 'waga.png'))
    
def dokus(params):
    iconBase = 'special://home/addons/' + utils.addonID + '/resources/dokus/'
    utils.addDir('WAGA LIVESTREAMS', 'plugin://plugin.video.wagasworld/?fanart&mode=1&name=%5bCOLOR%20red%5d%5bB%5d%e2%80%a2%20%5b%2fB%5d%20%5b%2fCOLOR%5d%5bCOLOR%20white%5d%5bCOLOR%20red%5dW%5b%2fCOLOR%5dagas%5bCOLOR%20red%5dW%5b%2fCOLOR%5dorld%5b%2fCOLOR%5d%5bCOLOR%20white%5d%5bCOLOR%20red%5d%2024%2f7%5b%2fCOLOR%5d%20%5bCOLOR%20white%5dChannels%5b%2fCOLOR%5d&url=https%3a%2f%2fbit.ly%2f30N9p1k', xbmc.translatePath(iconBase + 'waga.png'))
    utils.addDir('WAGA TUBE', 'plugin://plugin.video.youtube/channel/UCoxciX-04biA_KwxKhus1aw/playlists/', xbmc.translatePath(iconBase + 'waga.png'))
    utils.addDir('CRIME TUBE', 'plugin://plugin.video.yt_crime/', xbmc.translatePath(iconBase + 'crime.png'))
    utils.addDir('ALL KIND OF MUSIC', 'plugin://plugin.video.All.Kinds.of.Music/', xbmc.translatePath(iconBase + 'music.png'))
    utils.addDir('YOUTUBE MUSIC', 'plugin://plugin.video.spotitube/', xbmc.translatePath(iconBase + 'ytmusic.png'))
    utils.addDir('RADIO', 'plugin://plugin.program.super.favourites/?content_type&fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ffanart.jpg&image=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.program.super.favourites%2ficon.png&label=%5bCOLOR%20gold%5dRADIO%5b%2fCOLOR%5d&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.super.favourites%2fSuper%20Favourites%2fRADIO', xbmc.translatePath(iconBase + 'music.png'))
    utils.addDir('YOUTUBE', 'plugin://plugin.video.youtube/', xbmc.translatePath(iconBase + 'ytube.png'))
    utils.addDir('WORLD OF WRESTLING', 'plugin://plugin.video.WorldOfWrestling/', xbmc.translatePath(iconBase + 'wwf.png'))
    

def pornbox(params):
    iconBase = 'special://home/addons/' + utils.addonID + '/resources/pornbox/'
    utils.addDir('Adriana XXX TV', 'plugin://plugin.video.adrianaxxx/?fanart=https%3a%2f%2fdm.victoriassecret.com%2fimagefeatures%2f0x0%2f1268512941558%2f021919-cp-desktop-all-lingerie.jpg&mode=1&name=%5bB%5d%5bI%5d%5bCOLOR%20brown%5dXXX%20LISTA%5b%2fB%5d%5b%2fCOLOR%5d%5b%2fI%5d&url=https%3a%2f%2fzadarbuild.com.hr%2fAdrianaXXX%2flistaXXXMIX.xml', xbmc.translatePath(iconBase + 'hot.png'))
    utils.addDir('Adriana XXX VOD', 'plugin://plugin.video.adrianaxxx/?fanart=http%3a%2f%2flegacy.duke4.net%2fimages%2fnewspost_images%2fsexygirl.jpg&mode=1&name=%5bB%5d%5bI%5d%5bCOLOR%20teal%5dXXX%2fVOD%5b%2fB%5d%5b%2fCOLOR%5d%5b%2fI%5d&url=https%3a%2f%2fzadarbuild.com.hr%2fAdrianaXXX%2flistaXXXVOD.xml', xbmc.translatePath(iconBase + 'hot.png'))
    utils.addDir('VOODOO XXX TV', 'plugin://plugin.video.voodoo-tv/?fanart=https%3a%2f%2f&mode=1&name=%5bB%5d%5bI%5d%5bCOLOR%20red%5dVoodoo%5bCOLOR%20beige%5d%5bCOLOR%20white%5dXXX%5b%2fB%5d%5b%2fI%5d%5b%2fCOLOR%5d&url=https%3a%2f%2fpastebin.com%2fraw%2fAUXQ3LzS', xbmc.translatePath(iconBase + 'hot.png'))
    utils.addDir('PSYCO XXX VOD', 'plugin://plugin.video.PsycoTV/?fanart=%2fstorage%2femulated%2f0%2fAndroid%2fdata%2ftv.vavoo.app%2ffiles%2f.vavoo%2faddons%2fplugin.video.PsycoTV%2ffanart.jpg&mode=1&name=%5bB%5d%5bCOLOR%20white%5dPsycoTV%20%5b%2fCOLOR%5d%5bCOLOR%20red%5dXXX%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fraw.githubusercontent.com%2fPsycoTV%2fPsycoTV%2fmaster%2fxxx', xbmc.translatePath(iconBase + 'hot.png'))
    utils.addDir('CHATURBATE', 'plugin://plugin.video.chaturbate/', xbmc.translatePath(iconBase + 'hot.png'))
    utils.addDir('XXX CLIPZ', 'plugin://plugin.video.vavooto/?action=erotic&cancel=home', xbmc.translatePath(iconBase + 'hot.png'))


def erotic(params):

    def url(plugin, u):
        fields = ('title', 'director', 'genre', 'type', 'icon', 'url')
        params = '&'.join((k + ':' + u[k] for k in fields))
        params = urllib2.quote(params.encode('ascii', 'ignore'))
        utils.addDir(u['title'], 'plugin://' + plugin + '/?url=' + params, u['special_icon'])

    addonpath = os.path.split(os.path.dirname(__file__))[0]
    url('plugin.video.videodevil', {'title': 'Ah',
     'director': 'VideoDevil',
     'genre': 'Ah',
     'type': 'rss',
     'icon': addonpath + '/plugin.video.videodevil/resources/images/ahme.png',
     'special_icon': 'special://home/addons/plugin.video.videodevil/resources/images/ahme.png',
     'url': 'ahme.com.cfg'})
    url('plugin.video.videodevil', {'title': 'EPORNER',
     'director': 'VideoDevil',
     'genre': 'EPORNER',
     'type': 'rss',
     'icon': addonpath + '/plugin.video.videodevil/resources/images/eporner.png',
     'special_icon': 'special://home/addons/plugin.video.videodevil/resources/images/eporner.png',
     'url': 'eporner.com.cfg'})
    url('plugin.video.videodevil', {'title': 'Faapy',
     'director': 'VideoDevil',
     'genre': 'faapy.com',
     'type': 'rss',
     'icon': 'http://faapy.com/images_new/logo.png',
     'special_icon': 'http://faapy.com/images_new/logo.png',
     'url': 'faapy.com.cfg'})
    url('plugin.video.videodevil', {'title': 'Fapdu',
     'director': 'VideoDevil',
     'genre': 'fapdu',
     'type': 'rss',
     'icon': 'http://cdn-w.fapdu.com/FapDu/fo1-01.png',
     'special_icon': 'http://cdn-w.fapdu.com/FapDu/fo1-01.png',
     'url': 'fapdu.com.cfg'})
    url('plugin.video.videodevil', {'title': 'GirlfriendVideos',
     'director': 'VideoDevil',
     'genre': 'GirlfriendVideos',
     'type': 'rss',
     'icon': addonpath + '/plugin.video.videodevil/resources/images/gfvideos.png',
     'special_icon': 'special://home/addons/plugin.video.videodevil/resources/images/gfvideos.png',
     'url': 'gfvideos.com.cfg'})
    url('plugin.video.videodevil', {'title': 'Hentaigasm',
     'director': 'VideoDevil',
     'genre': 'hentaigasm',
     'type': 'rss',
     'icon': 'http://hentaigasm.com/wp-content/themes/detube/images/logo.png',
     'special_icon': 'http://hentaigasm.com/wp-content/themes/detube/images/logo.png',
     'url': 'hentaigasm.com.cfg'})
    url('plugin.video.videodevil', {'title': 'MadThumbs',
     'director': 'VideoDevil',
     'genre': 'madthumbs',
     'type': 'rss',
     'icon': addonpath + '/plugin.video.videodevil/resources/images/madthumbs.png',
     'special_icon': 'special://home/addons/plugin.video.videodevil/resources/images/madthumbs.png',
     'url': 'madthumbs.com.cfg'})
    url('plugin.video.videodevil', {'title': 'Motherless',
     'director': 'VideoDevil',
     'genre': 'Motherless',
     'type': 'rss',
     'icon': 'http://motherless.com/images/logo8888.gif',
     'special_icon': 'http://motherless.com/images/logo8888.gif',
     'url': 'motherless.com.cfg'})
    url('plugin.video.videodevil', {'title': 'MovieFap',
     'director': 'VideoDevil',
     'genre': 'MovieFap',
     'type': 'rss',
     'icon': 'http://www.moviefap.com/images/logo.gif',
     'special_icon': 'http://www.moviefap.com/images/logo.gif',
     'url': 'moviefap.com.cfg'})
    url('plugin.video.videodevil', {'title': 'Pornburst.xxx',
     'director': 'VideoDevil',
     'genre': 'Pornbust.xxx',
     'type': 'rss',
     'icon': addonpath + '/plugin.video.videodevil/resources/images/pornburst.png',
     'special_icon': 'special://home/addons/plugin.video.videodevil/resources/images/pornburst.png',
     'url': 'pornburst.xxx.cfg'})
    url('plugin.video.videodevil', {'title': 'Porn.com',
     'director': 'VideoDevil',
     'genre': 'Porn.com',
     'type': 'rss',
     'icon': addonpath + '/plugin.video.videodevil/resources/images/porn.com-logo.png',
     'special_icon': 'special://home/addons/plugin.video.videodevil/resources/images/porn.com-logo.png',
     'url': 'porn.com.cfg'})
    url('plugin.video.videodevil', {'title': 'Pornhd',
     'director': 'VideoDevil',
     'genre': 'pornhd',
     'type': 'rss',
     'icon': addonpath + '/plugin.video.videodevil/resources/images/pornhdlogo.png',
     'special_icon': 'special://home/addons/plugin.video.videodevil/resources/images/pornhdlogo.png',
     'url': 'pornhd.com.cfg'})
    url('plugin.video.videodevil', {'title': 'Pornhub',
     'director': 'VideoDevil',
     'genre': 'Pornhub',
     'type': 'rss',
     'icon': addonpath + '/plugin.video.videodevil/resources/images/pornhub.png',
     'special_icon': 'special://home/addons/plugin.video.videodevil/resources/images/pornhub.png',
     'url': 'pornhub.com.cfg'})
    url('plugin.video.videodevil', {'title': 'SpankWire',
     'director': 'VideoDevil',
     'genre': 'SpankWire',
     'type': 'rss',
     'icon': addonpath + '/plugin.video.videodevil/resources/images/spankwire.png',
     'special_icon': 'special://home/addons/plugin.video.videodevil/resources/images/spankwire.png',
     'url': 'spankwire.com.cfg'})


def mediathek(params):
    iconBase = 'special://home/addons/'
    utils.addDir('ARD Mediathek', 'plugin://plugin.video.ardmediathek_de', iconBase + utils.addonID + '/resources/ardmediathek.png')
    utils.addDir('ATV.at', 'plugin://plugin.video.atv_at', iconBase + 'plugin.video.atv_at/icon.png')
    utils.addDir('Arte.tv', 'plugin://plugin.video.arte_tv', iconBase + 'plugin.video.arte_tv/icon.png')
    utils.addDir('Doku5.com', 'plugin://plugin.video.doku5.com', iconBase + 'plugin.video.doku5.com/icon.png')
    utils.addDir('3Sat', 'plugin://plugin.video.mediathek/?type=3Sat', iconBase + 'plugin.video.mediathek/resources/logos/png/3Sat.png')
    utils.addDir('KI.KA', 'plugin://plugin.video.mediathek/?type=KI.KA', iconBase + 'plugin.video.mediathek/resources/logos/png/KI.KA-Plus.png')
    utils.addDir('ORF', 'plugin://plugin.video.mediathek/?type=ORF', iconBase + 'plugin.video.mediathek/resources/logos/png/ORF.png')
    utils.addDir('Servus TV', 'plugin://plugin.video.servustv_com', iconBase + utils.addonID + '/resources/mediatheken/iconSTV.png')
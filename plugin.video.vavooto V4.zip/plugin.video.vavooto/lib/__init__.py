# Embedded file name: ./lib/__init__.py
pass
# Embedded file name: ./lib/service.py
import xbmc
import xbmcgui

def main():
    home = xbmcgui.Window(10000)
    if home.getProperty('service_vavooto') == 'true':
        xbmc.log('DLDB service is already running', xbmc.LOGERROR)
        return
    home.setProperty('service_vavooto', 'true')
    try:
        monitor = xbmc.Monitor()
        while home.getProperty('Vavoo_Ready') != 'true':
            if monitor.waitForAbort(1):
                return

        import dldb
        dldb.service2()
    finally:
        home.clearProperty('service_vavooto')


if __name__ == '__main__':
    main()
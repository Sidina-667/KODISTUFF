# Embedded file name: ./lib/sky.py
import sys
import re
import json
import datetime
import requests
import xbmc
import xbmcplugin
import vjackson
import utils
client = requests.session()

class channels:

    def __init__(self):
        self.list = []
        self.items = []
        self.uk_datetime = self.uk_datetime()
        self.sky_now_link = 'http://epgservices.sky.com/5.1.1/api/2.0/channel/json/%s/now/nn/0'
        self.sky_programme_link = 'http://tv.sky.com/programme/channel/%s/%s/%s.json'

    def get(self):
        channels = [('01', 'Sky Premiere', '4021'),
         ('02', 'Sky Premiere +1', '1823'),
         ('03', 'Sky Showcase', '4033'),
         ('04', 'Sky Greats', '1815'),
         ('05', 'Sky Disney', '4013'),
         ('06', 'Sky Family', '4018'),
         ('07', 'Sky Action', '4014'),
         ('08', 'Sky Comedy', '4019'),
         ('09', 'Sky Crime', '4062'),
         ('10', 'Sky Drama', '4016'),
         ('11', 'Sky Sci Fi', '4017'),
         ('12', 'Sky Select', '4020'),
         ('13', 'Film4', '4044'),
         ('14', 'Film4 +1', '1629'),
         ('15', 'TCM', '3811'),
         ('16', 'TCM +1', '5275')]
        data = utils.cache['short'].get('sky')
        if data:
            try:
                self.list = json.loads(data)
            except Exception:
                pass

        if not self.list:
            self.list = []
            threads = []
            for i in channels:
                threads.append(utils.Thread(self.sky_list, i[0], i[1], i[2]))

            [ i.start() for i in threads ]
            [ i.join() for i in threads ]
            threads = []
            for i in range(0, len(self.items)):
                threads.append(utils.Thread(self.items_list, self.items[i]))

            [ i.start() for i in threads ]
            [ i.join() for i in threads ]
            try:
                self.list = sorted(self.list, key=lambda k: k['channelNumber'])
            except Exception:
                raise

            print utils.cache['short'].set('sky', json.dumps(self.list))
        self.channelDirectory(self.list)
        return self.list

    def sky_list(self, num, channel, id):
        url = self.sky_now_link % id
        result = client.get(url, timeout=30).content
        result = json.loads(result)
        match = result['listings'][id][0]['url']
        dt1 = self.uk_datetime.strftime('%Y-%m-%d')
        dt2 = int(self.uk_datetime.strftime('%H'))
        if dt2 < 6:
            dt2 = 0
        elif dt2 >= 6 and dt2 < 12:
            dt2 = 1
        elif dt2 >= 12 and dt2 < 18:
            dt2 = 2
        elif dt2 >= 18:
            dt2 = 3
        url = self.sky_programme_link % (id, str(dt1), str(dt2))
        result = client.get(url, timeout=30).content
        result = json.loads(result)
        result = result['listings'][id]
        result = [ i for i in result if i['url'] == match ][0]
        year = result['d']
        year = re.findall('[(](\\d{4})[)]', year)[0].strip()
        year = year.encode('utf-8')
        title = result['t']
        title = title.replace('(%s)' % year, '').strip()
        title = utils.replaceHTMLCodes(title)
        title = title.encode('utf-8')
        self.items.append((title,
         year,
         channel,
         num))

    def items_list(self, i):
        params = {'query': i[0],
         'year': i[1]}
        item = vjackson.makeRequest('all', params, addResolution=False, cache=False)
        item = item[0]
        item['channelName'] = i[2]
        item['channelNumber'] = i[3]
        self.list.append(item)

    def uk_datetime(self):
        dt = datetime.datetime.utcnow() + datetime.timedelta(hours=0)
        d = datetime.datetime(dt.year, 4, 1)
        dston = d - datetime.timedelta(days=d.weekday() + 1)
        d = datetime.datetime(dt.year, 11, 1)
        dstoff = d - datetime.timedelta(days=d.weekday() + 1)
        if dston <= dt < dstoff:
            return dt + datetime.timedelta(hours=1)
        else:
            return dt

    def channelDirectory(self, items):
        if items is None or len(items) == 0:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            sys.exit()
        vjackson.createDirectory('all', 'movie', {}, items)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)
        return
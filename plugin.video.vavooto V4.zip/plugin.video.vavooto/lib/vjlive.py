# uncompyle6 version 3.7.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.17 (default, Sep 30 2020, 13:38:04) 
# [GCC 7.5.0]
# Embedded file name: ./lib/vjlive.py
# Compiled at: 2022-04-30 22:39:32
import xbmcplugin, xbmcgui, sys, xbmc, json, re, time, utils, threading
BASEURL = 'https://www2.vavoo.to/'

def action_channel(params):
    progress = xbmcgui.DialogProgress()
    try:
        progress.create('VAVOO.TO', u'Der Stream wird gestartet...')
        progress.update(25)
        from urlresolver import resolve
        resolvedUrl = resolve(params['url'])
        if '|' not in resolvedUrl:
            resolvedUrl += '|'
        resolvedUrl += '&seekable=0'
        progress.update(50)
        o = xbmcgui.ListItem()
        o.setInfo('Video', {'title': params['title'], 'Seekable': 'false'})
        o.setLabel(params['title'])
        o.setThumbnailImage(params['thumb'])
        o.setPath(resolvedUrl)
        o.setProperty('IsPlayable', 'true')
        o.setProperty('IsNotSeekable', 'true')
        o.setProperty('Seekable', 'false')
        xbmcplugin.setResolvedUrl(utils.getPluginhandle(), True, o)
        progress.update(75)
    finally:
        if progress:
            progress.close()


def action_channels(params):
    return action_live(params)


def action_live(params, action='live', channelFilter=None):
    channels = makeRequest('live2/index', {'output': 'json'}, cache='medium')
    groups = {}
    for c in channels:
        if c['group'] not in groups:
            groups[c['group']] = {}
        g = groups[c['group']]
        name = re.sub('( (SD|HD|FHD|UHD|H265))?( \\(BACKUP\\))? \\(\\d+\\)$', '', c['name'])
        if name not in g:
            g[name] = []
        g[name].append(c)

    if params.get('group') and params.get('name'):
        livePlay(action, groups, params['group'], params['name'])
    elif params.get('group'):
        liveGroupIndex(action, groups, params.get('group'))
    else:
        liveIndex(action, groups)


class Player(xbmc.Player):
    pass


def livePlay(action, groups, group, name):
    try:
        m = groups[group][name]
        m[0]
    except IndexError:
        xbmcgui.Dialog().ok('Der Kanal ist nicht verf\xc3\xbcgbar', 'Bitte versuche es sp\xc3\xa4ter erneut.')
        return

    if len(m) > 1 or utils.DEBUG:
        captions = list(sorted([ n['name'] for n in m ]))
        index = xbmcgui.Dialog().select('Stream w\xc3\xa4hlen', captions)
        if index < 0:
            raise ValueError('CANCELED')
        n = m[index]
    else:
        n = m[0]
    progress = xbmcgui.DialogProgress()
    try:
        progress.create('VAVOO.TO', u'Der Stream wird gestartet...')
        progress.update(15)
        xbmc.sleep(50)
        o = xbmcgui.ListItem()
        if n['logo']:
            o.setThumbnailImage(n['logo'])
        o.setInfo('Video', {'title': n['name'], 'Seekable': 'false', 'SeekEnabled': 'false'})
        o.setLabel(n['name'])
        o.setPath(n['url'] + '?n=1&b=5&vavoo_auth=' + 'eyJkYXRhIjoie1widGltZVwiOjI2MDk0NDA0MDEwMjksXCJ2YWxpZFVudGlsXCI6MjYwOTQ0MTAwMTAyOSxcImlwc1wiOltcIjE1NC45Mi4wLjIzXCJdLFwicnVsZXNldFwiOlwiZ3Vlc3RcIixcInZlcmlmaWVkXCI6dHJ1ZSxcImVycm9yXCI6bnVsbCxcImFwcFwiOntcInBsYXRmb3JtXCI6XCJ2YXZvb1wiLFwidmVyc2lvblwiOlwiMi42XCIsXCJzZXJpdmNlXCI6XCIxLjIuMjZcIixcIm9rXCI6dHJ1ZX0sXCJ1dWlkXCI6XCI1T2MyVkR3UmdyMjlSMmVXZTh1Zi9ZUitDOHZaOXAvdVM5eCtSY2cwS1FvPVwifSIsInNpZ25hdHVyZSI6ImFTdGJpT2U0V0gyTzBrZm9TN0VTV2JXTFk3RS9vVTN1OWJNeml2bDdKWkc1eW1HRElmam92blVlQUFpbVdzc3NHUDNOeHg5VDAvL0hnSUlPV21xMkpiUXJ4NFBlYVdQMkM5U1ZNTFA5cjMzYnNURXEvMXZWeVZ3RnBBMm00bTdrNHVpZkpablk4enBqNnNWNGdHUDBGd0NBbCszRnkrSm9zWmhGU0FXYkNUYz0ifQ==' + '|User-agent=VAVOO/1.51' + '|seekable=0')
        o.setProperty('IsPlayable', 'true')
        o.setProperty('IsNotSeekable', 'true')
        o.setProperty('Seekable', 'false')
        o.setProperty('SeekEnabled', 'false')
        progress.update(30)
        xbmcplugin.setResolvedUrl(utils.getPluginhandle(), True, o)
        progress.update(45)
        abortReason = ''
        step = 1
        t = time.time()
        player = Player()
        try:
            while not abortReason:
                if xbmc.abortRequested:
                    abortReason = 'aborted'
                elif progress.iscanceled():
                    abortReason = 'cancelled'
                elif time.time() - t > 60:
                    abortReason = 'timeout'
                elif step == 1:
                    if player.isPlaying():
                        progress.update(60)
                        step = 2
                elif step == 2:
                    if xbmc.getInfoLabel('VideoPlayer.VideoResolution'):
                        progress.update(75)
                        step = 3
                elif step == 3:
                    if True or player.isPlaying() and player.getTime() > 0.1:
                        progress.update(100)
                        break
                if not abortReason:
                    xbmc.sleep(250)

            if abortReason:
                player.stop()
                raise RuntimeError('Stream died! reason=%s' % abortReason)
        finally:
            del player

    finally:
        if progress:
            progress.close()
            del progress


def liveGroupIndex(action, groups, group):
    gName = group.encode('utf-8')
    g = groups[group]
    for name, m in sorted(g.items()):
        name = name.strip().encode('utf-8')
        url = utils.getPluginUrl({'action': action, 'group': gName, 'name': name})
        for n in m:
            if n['logo']:
                o = xbmcgui.ListItem(name, iconImage='special://home/addons/plugin.video.vavooto/channel.png', thumbnailImage='special://home/addons/plugin.video.vavooto/channel.png')
                o.setThumbnailImage('special://home/addons/plugin.video.vavooto/channel.png')
                break
        else:
            o = xbmcgui.ListItem(name, iconImage='special://home/addons/plugin.video.vavooto/channel.png')

        o.setInfo(type='Video', infoLabels={'Title': name})
        o.setProperty('IsPlayable', 'true')
        o.setProperty('selectaction', 'play')
        xbmcplugin.addDirectoryItem(handle=utils.getPluginhandle(), url=url, listitem=o, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)


def liveIndex(action, groups):
    LIVE_GROUP_ALIASES = (
     (1, u'Germany', u'Deutschland', 'flags/country/de.png', None),
     (2, u'Turkey', u'T\xfcrkei', 'flags/country/tr.png', None),
     (3, u'Denmark', u'D\xe4nemark', 'flags/country/dk.png', None),
     (4, u'Sports International', u'Sport International', 'flags/country/eu.png', None),
     (99999, u'Albania', u'Albanien', 'flags/country/al.png', None),
     (99999, u'Arabia', u'Arabisch', 'flags/country/ae.png', None),
     (99999, u'Azerbaijan', u'Azerbaijan', 'flags/country/az.png', None),
     (
      99999, u'Balkans', u'Balkan', 'special://home/addons/' + utils.addonID + '/resources/yu.png', None),
     (99999, u'Bulgaria', u'Bulgarien', 'flags/country/bg.png', None),
     (99999, u'France', u'Frankreich', 'flags/country/fr.png', None),
     (99999, u'Netherlands', u'Niederlande', 'flags/country/nl.png', None),
     (99999, u'Poland', u'Polen', 'flags/country/pl.png', None),
     (99999, u'Romania', u'Rum\xe4nien', 'flags/country/ro.png', None),
     (99999, u'Portugal', u'Portugal', 'flags/country/pt.png', None),
     (99999, u'Italy', u'Italien', 'flags/country/it.png', None),
     (99999, u'Belgium', u'Belgien', 'flags/country/be.png', None),
     (99999, u'United Kingdom', u'England', 'flags/country/gb.png', None),
     (99999, u'Greece', u'Griechenland', 'flags/country/gr.png', None),
     (99999, u'Russia', u'Russland', 'flags/country/ru.png', None),
     (99999, u'Spain', u'Spanien', 'flags/country/es.png', None),
     (99999, u'Sweden', u'Schweden', 'flags/country/se.png', None),
     (99999, u'Iran', u'Iran', 'flags/country/ir.png', None))
    index = []
    for group, g in groups.items():
        for i, (position, alias, name, icon, url) in enumerate(LIVE_GROUP_ALIASES):
            if alias == group:
                i = position
                title = name
                break
        else:
            i, title, icon, url = (
             99999, group, 'DefaultFolder.png', None)

        if url is None:
            url = utils.getPluginUrl({'action': action, 'group': group.encode('utf-8')})
        index.append((i, title.strip() + u' (' + str(len(g)) + u' Kan\xe4le)', icon, url))

    for i, title, icon, url in sorted(index):
        o = xbmcgui.ListItem(title, iconImage=icon)
        o.setInfo(type='Video', infoLabels={'Title': title})
        o.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=utils.getPluginhandle(), url=url, listitem=o, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)
    return


def makeRequest(*args, **kwargs):
    data = _makeRequest(*args, **kwargs)
    if isinstance(data, dict):
        if data.get('error'):
            if str(data['error']).lower() == 'incompatible':
                xbmcgui.Dialog().ok('VAVOO Version in\xc2\xadkom\xc2\xadpa\xc2\xadti\xc2\xadbel', 'Bitte deinstalliere diese Version und lade die aktuelle kostenlose VAVOO App von der Webseite unter www.vavoo.tv/software oder \xc3\xbcber den Google PlayStore herunter.')
            raise ValueError(data['error'])
    return data


def _makeRequest(function, params, data=None, files=None, addLanguage=True, add_locale=True, cache='medium'):
    t = time.time()
    params = dict(params)
    params.pop('action', None)
    if addLanguage:
        params['language'] = utils.getLanguage(params)
    if add_locale and 'locale' not in params:
        params['locale'] = utils.getLocale(params)
    params['vavoo_auth'] = utils.getAuthSignature()
    print 'Request: %s / %s' % (function, json.dumps(params))
    if not utils.DEBUG and cache:
        if files:
            raise RuntimeError('File upload and cache is invalid')
        cacheKey = function + '?' + ('&').join([ str(key) + '=' + str(value) for key, value in sorted(params.items()) ])
        cacheKey = 'vjackson/' + str(hash(cacheKey))
        content = utils.cache[cache].get(cacheKey)
        if content:
            return json.loads(content)
    headers = {'Validation-Token': str(int(time.time()))}
    if data is None and files is None:
        response = utils.getSession().get(BASEURL + function, params=params, headers=headers)
    else:
        response = utils.getSession().post(BASEURL + function, params=params, headers=headers, data=data, files=files)
    content = response.content
    print 'Request time: %s' % (time.time() - t) + ', content lenth: %s' % len(content)
    try:
        result = json.loads(content)
    except Exception:
        print repr(content)
        raise

    if not utils.DEBUG and cache and response.status_code in (200, 201, 301, 302):
        utils.cache[cache].set(cacheKey, content)
    return result
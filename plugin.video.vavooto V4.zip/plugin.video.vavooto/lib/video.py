# uncompyle6 version 3.7.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.17 (default, Sep 30 2020, 13:38:04) 
# [GCC 7.5.0]
# Embedded file name: ./lib/video.py
# Compiled at: 2022-04-14 18:25:36
import xbmcplugin, sys, xbmc, urlparse, utils

def main():
    params = urlparse.parse_qs(sys.argv[2][1:])
    params = {key:value[0] if len(value) == 1 else value for key, value in params.items()}
    errorParams = {'function': 'main', 
       'original': dict(params), 
       'current': params}
    try:
        action = params.pop('action', '')
        if not action:
            url = urlparse.urlparse(sys.argv[0])
            action = url.path.strip('/')
        if not action or action == 'home':
            xbmc.executebuiltin('ActivateWindow(Home)')
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        elif action in ('kids', 'erotic', 'mediathek'):
            import lists
            xbmcplugin.setContent(int(sys.argv[1]), 'files')
            xbmcplugin.setPluginCategory(int(sys.argv[1]), lists.ACTIONS[action])
            getattr(lists, action)(params)
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)
        elif action == 'sky':
            import sky
            sky.channels().get()
        elif action == 'trailer':
            import trailer
            trailer.play(params.get('name'), params.get('url'))
        elif action == 'v1_download/list':
            import dldb
            dldb.downloadList(params)
        elif action == 'download/list':
            import dldb2
            dldb2.downloadList(params)
        elif action in ('channels', 'live'):
            import vjlive
            getattr(vjlive, 'action_' + action)(params)
            xbmcplugin.endOfDirectory(utils.getPluginhandle(), succeeded=True, cacheToDisc=True)
        else:
            mod = None
            if action in ('index', 'indexMovie', 'indexSerie', 'search'):
                action = 'v2_%s' % action
            if action.startswith('v1_'):
                import vjackson
                mod = vjackson
                action = action[3:]
            elif action.startswith('v2_'):
                import vjackson2
                mod = vjackson2
                action = action[3:]
            else:
                import vjackson
                mod = vjackson
            if not mod.main(action, params):
                raise Exception('Unknown action: %r' % [action, params])
    except Exception as e:
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
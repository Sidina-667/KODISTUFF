# uncompyle6 version 3.7.4
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.17 (default, Sep 30 2020, 13:38:04) 
# [GCC 7.5.0]
# Embedded file name: ./lib/vjackson2.py
# Compiled at: 2022-04-30 22:39:18
import xbmcaddon, xbmcplugin, xbmcgui, sys, xbmc, os, urllib, json, re, time, utils, threading, urllib2, urlparse
BASEURL = 'https://www2.vavoo.to/ccapi/'
MAX_SEARCH_HISTORY_ITEMS = 20
DEBUG = os.path.exists(xbmc.translatePath('special://home/debug').decode('utf-8'))
USE_CACHE = False if DEBUG else True
DEBUG_HOSTERS = DEBUG
REPORT_CAPTURE_SCREENSHOTS = False
try:
    path = xbmc.translatePath('special://home/userdata/advancedsettings.xml')
    if not os.path.exists(path):
        with open(path, 'w') as (f):
            f.write('<advancedsettings><cache><buffermode>1</buffermode><memorysize>52428800</memorysize></cache></advancedsettings>')
except Exception:
    pass

def main(action, params):
    try:
        indexes = ('index', 'indexMovie', 'indexSerie')
        actions = ('home', 'list', 'seasons', 'episodes', 'tag')
        noCacheActions = ('search', )
        actionFn = 'action_' + action
        if action in indexes:
            globals()[actionFn](params)
            xbmcplugin.endOfDirectory(utils.getPluginhandle(), succeeded=True, cacheToDisc=True)
        elif action in actions:
            globals()[actionFn](params)
            xbmcplugin.endOfDirectory(utils.getPluginhandle(), succeeded=True, cacheToDisc=True)
        elif action in noCacheActions:
            globals()[actionFn](params)
            xbmcplugin.endOfDirectory(utils.getPluginhandle(), succeeded=True, cacheToDisc=False)
        elif action == 'get':
            globals()[actionFn](params)
        elif action == 'settings':
            utils.addon.openSettings(sys.argv[1])
        else:
            return False
    except Exception:
        cancel = params.get('cancel', '').lower()
        if cancel == 'home':
            action_home(params)
        raise

    return True


def action_home(params):
    xbmc.executebuiltin('ActivateWindow(Home)')
    xbmcplugin.endOfDirectory(utils.getPluginhandle())


def action_index(params):
    xbmcplugin.setContent(utils.getPluginhandle(), 'files')
    addDir2('Filme', 'movies', 'v2_indexMovie', genre=params.get('genre', ''))
    addDir2('Serien', 'series', 'v2_indexSerie', genre=params.get('genre', ''))
    addDir2('Suche', 'search', 'v2_search', id='all.popular')
    addDir2('Einstellungen', 'settings', 'v2_settings', genre=params.get('genre', ''))


def action_indexMovie(params):
    xbmcplugin.setContent(utils.getPluginhandle(), 'movies')
    addDir2('Beliebte Filme', 'new2', 'v2_list', id='movie.popular')
    addDir2('Beliebte Filme (Deutschland)', 'new2', 'v2_list', id='movie.popularDE')
    addDir2('Angesagte Filme', 'new2', 'v2_list', id='movie.trending')
    addDir2('Angesagte Filme (Deutschland)', 'new2', 'v2_list', id='movie.trendingDE')
    addDir2('Suche', 'search', 'v2_search', id='movie.popular')
    addDir2('Einstellungen', 'settings', 'v2_settings', genre=params.get('genre', ''))


def action_indexSerie(params):
    xbmcplugin.setContent(utils.getPluginhandle(), 'tvshows')
    addDir2('Beliebte Serien', 'new2', 'v2_list', id='series.popular')
    addDir2('Angesagte Serien', 'new2', 'v2_list', id='series.trending')
    addDir2('Suche', 'search', 'v2_search', id='series.popular')
    addDir2('Einstellungen', 'settings', 'v2_settings', genre=params.get('genre', ''))


ITEM_TYPES = {'movie': 'Film', 
   'serie': 'Serie'}
RESOLUTION_OPTIONS = (
 'all', 'hd', 'sd')
STREAM_SELECT_OPTIONS = ('hosters2', 'auto', 'grouped')
PLAYBACK_RESOLUTION_OPTIONS = (
 'Highest', '1080p', '720p', '480p', '360p', 'Manual')
LANGUAGE_CODES = {'de': 'DE', 
   'en': 'EN'}
LANGUAGE_NAMES = {'de': {'de': 'Deutsch', 
          'en': 'Englisch'}, 
   'en': {'de': 'German', 
          'en': 'English'}}

def getHosters(params):
    hosters = []
    with open(xbmc.translatePath('special://home/addons/' + utils.addonID + '/resources/settings.xml').decode('utf-8'), 'r') as (f):
        data = f.read()
    for label, shortlabel, default in re.findall('<setting .* label="([^"]+)" shortlabel="([^"]+)" default="(true|false)"', data):
        value = utils.addon.getSetting('hoster_' + label) or default
        if value != 'true':
            hosters.append('!' + label)

    return (',').join(hosters)


def getResolution(params):
    if 'resolution' in params:
        return params['resolution']
    return RESOLUTION_OPTIONS[int(utils.addon.getSetting('resolution') or 1)]


def getPlaybackResolution():
    return PLAYBACK_RESOLUTION_OPTIONS[int(utils.addon.getSetting('playback_resolution') or 0)]


def getStreamSelect():
    if DEBUG_HOSTERS:
        return 'hosters2'
    return STREAM_SELECT_OPTIONS[int(utils.addon.getSetting('stream_select') or 0)]


def getAutoTryNextStream():
    if DEBUG_HOSTERS:
        return False
    return utils.addon.getSetting('auto_try_next_stream') != 'false'


def prepareListItem(params, e, isPlayable=False, callback=None):
    infos = {}
    properties = {}

    def getMeta(*paths, **kwargs):
        for path in paths:
            f = e
            for p in path:
                try:
                    f = f[p]
                except (KeyError, TypeError):
                    f = None
                    break

            if f:
                return f

        return kwargs.get('default', None)

    def setInfo(key, value):
        if value:
            if type(value) is list:
                infos[key] = (', ').join(value)
            else:
                infos[key] = value

    def setProperty(key, value):
        if value:
            properties[key] = value

    def setInfoPeople(key, value):
        if value:
            setInfo(key, value)

    title = e['name']
    attrs = []
    if attrs:
        title += ' (' + (', ').join(attrs) + ')'
    if 'channelName' in e:
        title = '[B]' + e['channelName'] + '[/B]: ' + title
    setInfo('title', title)
    setInfo('originaltitle', e['originalName'])
    setInfo('year', getMeta(('year', )))
    art = {'thumb': getMeta(('poster', ), default='DefaultVideo.png'), 
       'poster': getMeta(('poster', ), default='DefaultVideo.png'), 
       'banner': getMeta(('backdrop', ))}

    def updateInfos(data):
        setInfo('plot', data.get('description'))
        setInfo('code', data.get('id'))
        setInfo('premiered', data.get('releaseDate'))

    updateInfos(e)
    if not isMovie(e) and 'season' in params and 'current_episode' in e:
        ep = e['current_episode']
        season = params['season']
        episode = ep['episode']
        if season == 0:
            setInfo('TVShowTitle', 'Extras, Episode %s' % episode)
        else:
            setInfo('TVShowTitle', 'Season %s Episode %s' % (season, episode))
        setInfo('season', season)
        setInfo('episode', episode)
        episode_title = ep.get('name', None)
        if episode_title and not episode_title.startswith('Episode '):
            setInfo('TVShowTitle', episode_title)
        updateInfos(ep)
    genres = set()
    for g in getMeta(('genres', )) or tuple():
        genres.add(g)

    genres = (', ').join(sorted(genres))
    setInfo('genre', genres)
    countries = set()
    for g in getMeta(('countries', )) or tuple():
        countries.add(g)

    countries = (', ').join(sorted(countries))
    setInfo('country', countries)
    setInfoPeople('cast', getMeta(('cast', )))
    setInfo('director', getMeta(('director', )))
    setInfo('writer', getMeta(('writer', )))
    setProperty('selectaction', 'info')
    if isPlayable:
        setProperty('IsPlayable', 'true')
    contextMenuItems = []
    import dldb2
    dldb2.createListItemHook(params, e, isPlayable, properties, contextMenuItems)
    if callback:
        callback(params, e, isPlayable, properties, contextMenuItems)
    return (infos, properties, art, contextMenuItems)


def isMovie(e):
    print (
     '!!!!!!!!!!!', e)
    return e['id'].startswith('movie')


def createListItem(params, e, isPlayable=False, o=None, **kwargs):
    infos, properties, art, contextMenuItems = prepareListItem(params, e, isPlayable=isPlayable, **kwargs)
    if o is None:
        o = xbmcgui.ListItem()
    o.setInfo('Video', infos)
    o.setLabel(infos['title'])
    o.addContextMenuItems(contextMenuItems, False)
    for key, value in properties.items():
        if not isinstance(value, basestring):
            value = str(value)
        o.setProperty(key, value)

    if art:
        o.setArt(art)
        if art['thumb']:
            o.setThumbnailImage(art['thumb'])
    return o


def addNextPage(params, **kwargs):
    params = dict(params)
    params.update(kwargs)
    params['page'] = int(params.get('page', 1)) + 1
    addDir('>>> Weiter', utils.getPluginUrl(params))


def action_list(params):
    data = callApi2('list', {'id': params['id']})
    if isMovie(data['data'][0]):
        content = 'movies'
    else:
        content = 'tvshows'
    xbmcplugin.setContent(utils.getPluginhandle(), content)
    items = []
    for i, e in enumerate(data['data']):
        if isMovie(e):
            isPlayable = True
            isFolder = False
            action = 'v2_get'
        else:
            isPlayable = False
            isFolder = True
            action = 'v2_seasons'
        urlParams = {'action': action, 'id': str(e['id'])}
        o = createListItem(urlParams, e, isPlayable=isPlayable)
        items.append((i, urlParams, o, isFolder))

    for _, urlParams, o, isFolder in sorted(items):
        xbmcplugin.addDirectoryItem(handle=utils.getPluginhandle(), url=utils.getPluginUrl(urlParams), listitem=o, isFolder=isFolder)

    if data['next']:
        addDir('>>> Weiter', utils.getPluginUrl({'action': 'v2_list', 'id': data['next']}))


class action_search(object):
    db = None

    def __init__(self, params):
        self.params = params
        history = self.getHistory()
        if 'query' in params:
            params['query'] = params['query'].decode('utf-8')
            if params.get('exact') == 'true' and not params['query'].startswith('"'):
                params['query'] = '"' + params['query'] + '"'
            if params['query'] == '-':
                oKeyboard = xbmc.Keyboard(history[0] if history else '')
                oKeyboard.doModal()
                if not oKeyboard.isConfirmed():
                    self.index(history)
                    return
                params['query'] = oKeyboard.getText().strip()
                if not params['query']:
                    self.index(history)
                    return
                params['query'] = params['query'].decode('utf-8')
            elif 'delete' in params:
                c = self.getDatabase().cursor()
                try:
                    try:
                        c.execute('DELETE FROM search_history WHERE query=?', [params['query']])
                        self.db.commit()
                    except Exception:
                        import traceback
                        traceback.print_exc()

                finally:
                    c.close()

                self.index(self.getHistory())
                return
            if params.get('history', 'true') == 'true':
                c = self.getDatabase().cursor()
                try:
                    try:
                        c.execute('REPLACE INTO search_history (query, t) VALUES (?, ?)', [
                         params['query'], int(time.time())])
                        self.db.commit()
                    except Exception:
                        import traceback
                        traceback.print_exc()

                finally:
                    c.close()

            params['query'] = params['query'].encode('utf-8')
            params['id'] = '%s.search=%s' % (params['id'], params['query'].replace('.', '%2E'))
            action_list(params)
        else:
            self.index(history)

    def getDatabase(self):
        if not self.db:
            self.db = utils.Database(filename='vjackson.db')
            c = self.db.cursor()
            try:
                try:
                    c.execute('CREATE TABLE IF NOT EXISTS search_history (query TEXT PRIMARY KEY, t INTEGER)')
                    self.db.commit()
                except Exception:
                    import traceback
                    traceback.print_exc()

            finally:
                c.close()

        return self.db

    def getHistory(self):
        c = self.getDatabase().cursor()
        result = []
        try:
            try:
                c.execute('SELECT query FROM search_history ORDER BY t DESC')
                for query, in c:
                    result.append(query)

                for query in result[MAX_SEARCH_HISTORY_ITEMS - 1:]:
                    c.execute('DELETE FROM search_history WHERE query=?', [query])

                self.db.commit()
            except Exception:
                import traceback
                traceback.print_exc()

        finally:
            c.close()

        return result

    def index(self, history):
        addDir2('Neue Suche', 'search', 'v2_search', id=self.params.get('id', 'all.popular'), query='-')
        for query in history:
            url = utils.getPluginUrl({'action': 'v2_search', 'id': self.params['id'], 'query': query.encode('utf-8')})
            liz = xbmcgui.ListItem(query, iconImage='DefaultFolder.png', thumbnailImage=getIcon('query'))
            liz.setInfo(type='Video', infoLabels={'Title': query})
            ctx = [('L\xc3\xb6schen', 'ActivateWindow(Videos,' + url + '&delete=1)')]
            liz.addContextMenuItems(ctx, False)
            xbmcplugin.addDirectoryItem(handle=utils.getPluginhandle(), url=url, listitem=liz, isFolder=True)

        addDir2('Einstellungen', 'settings', 'v2_settings')


def getParamsLanguage(params, forceDialog=False):
    languages = params.pop('languages', '').split(',')
    if len(languages) == 1 and not forceDialog:
        params['language'] = languages[0]
    else:
        locale = utils.getLocale(params)
        captions = [ LANGUAGE_NAMES[locale][lang] for lang in languages ]
        index = xbmcgui.Dialog().select('Sprache w\xc3\xa4hlen', captions)
        if index < 0:
            return
        for key, value in LANGUAGE_NAMES[locale].items():
            if value == captions[index]:
                params['language'] = key
                break
        else:
            raise ValueError('Could not find language %s' % captions[index])


def action_seasons(params):
    getParamsLanguage(params)
    data = callApi2('info', params)
    seasons = list(sorted(map(int, data['seasons'].keys())))
    if len(seasons) == 1:
        params['season'] = seasons[0]
        action_episodes(params, data)
        return
    xbmcplugin.setContent(utils.getPluginhandle(), 'seasons')
    params['action'] = 'v2_episodes'
    for i in seasons:
        params['season'] = str(i)
        o = createListItem(params, data)
        if i == 0:
            o.setLabel('Extras')
        else:
            o.setLabel('Season ' + str(i))
        xbmcplugin.addDirectoryItem(handle=utils.getPluginhandle(), url=utils.getPluginUrl(params), listitem=o, isFolder=True)


def action_episodes(params, data=None):
    if 'language' not in params:
        getParamsLanguage(params)
    xbmcplugin.setContent(utils.getPluginhandle(), 'episodes')
    if data is None:
        data = callApi2('info', params)
    season = str(params['season'])
    params = {'action': 'v2_get', 'season': season}
    for i in data['seasons'][season]:
        params['id'] = '%s.%s.%s' % (data['id'], season, i['episode'])
        data['current_episode'] = i
        o = createListItem(params, data, isPlayable=True)
        o.setLabel('Season ' + season + ' Episode ' + str(i['episode']))
        xbmcplugin.addDirectoryItem(handle=utils.getPluginhandle(), url=utils.getPluginUrl(params), listitem=o, isFolder=False)

    return


KODI_LANGUAGE_TRANSLATION = {'': 'none', 
   'ger': 'de', 
   'eng': 'en'}

class Player(xbmc.Player):
    pass


class action_get(object):

    def __init__(self, params):
        self.params = params
        self.selectedParts = {}
        self.db = None
        self.mirrorsTried = 0
        try:
            self.run()
        except Exception:
            import traceback
            traceback.print_exc()
            raise

        return

    def getDatabase(self):
        if not self.db:
            self.db = utils.Database(filename='vjackson.db')
            c = self.db.cursor()
            try:
                try:
                    c.execute('CREATE TABLE IF NOT EXISTS hoster_weights (hoster TEXT, t INTEGER)')
                    self.db.commit()
                except Exception:
                    import traceback
                    traceback.print_exc()

            finally:
                c.close()

        return self.db

    def getHosterWeights(self):
        weights = {}
        c = self.getDatabase().cursor()
        try:
            try:
                c.execute('DELETE FROM hoster_weights WHERE t<?', [int(time.time()) - 604800])
                c.execute('SELECT hoster, COUNT(*) FROM hoster_weights')
                self.getDatabase().commit()
                for hoster, weight in c:
                    if hoster:
                        weights[hoster] = weight

            except Exception:
                import traceback
                traceback.print_exc()

        finally:
            c.close()

        return weights

    def getStreamSelect(self):
        return getStreamSelect()

    def setSuccessfulConnection(self, hoster):
        c = self.getDatabase().cursor()
        try:
            try:
                c.execute('INSERT INTO hoster_weights (hoster, t) VALUES (?, ?)', [hoster, int(time.time())])
                self.getDatabase().commit()
            except Exception:
                import traceback
                traceback.print_exc()

        finally:
            c.close()

    def init(self):
        self.player = Player()
        self.player.stop()
        if not self.params.get('language'):
            getParamsLanguage(self.params)
        if self.params.get('singleUrl', None):
            self.data = {'name': 'singleUrl', 'originalName': 'singleUrl'}
            self.mirrors = [
             {'type': 'url', 
                'url': self.params['singleUrl'], 
                'language': 'de'}]
        else:
            if self.params.get('trailer'):
                self.data = callApi2('info', self.params)
                self.mirrors = self.data.get('videos')
                if not self.mirrors:
                    raise ValueError('keine trailer gefunden')
                return False
            import dldb2
            if dldb2.downloadGet(self.params):
                return True
            self.data = callApi2('info', self.params)
            self.mirrors = callApi2('links', self.params)
            if not self.mirrors:
                raise ValueError('keine mirrors gefunden')
            return False
        return

    def run(self):
        if self.init():
            return
        else:
            weights = self.getHosterWeights()
            SUPERWEIGHTS = {'clipboard.cc': 5, 
               'kinoger.com': 4, 
               'openload.co': 3, 
               'streamango.com': 2, 
               'streamcloud.eu': 1}
            self.groups = []
            groupsByLanguage = {}
            locale = utils.getLocale(self.params)
            for i, mirror in enumerate(self.mirrors):
                if 'hoster' not in mirror:
                    mirror['hoster'] = urlparse.urlparse(mirror['url']).netloc
                mirror['caption'] = mirror['hoster']
                mirror['weight'] = SUPERWEIGHTS.get(mirror['hoster'], 0) * 10000000 + weights.get(mirror['hoster'], 0) * 1
                print 'WEIGHT = %s /// %s %s /// %s' % (
                 mirror['weight'],
                 SUPERWEIGHTS.get(mirror['hoster'], 0),
                 weights.get(mirror['hoster'], 0),
                 mirror['hoster'])
                mirror['language'] = mirror.get('language', mirror.get('languages', ['??'])[0])
                if mirror['language'] not in groupsByLanguage:
                    attrs = []
                    attrs.append(LANGUAGE_NAMES[locale].get(mirror['language'], mirror['language']))
                    group = {'caption': (', ').join(attrs), 
                       'mirrors': []}
                    group['priority'] = i
                    self.groups.append(group)
                    groupsByLanguage[mirror['language']] = group
                groupsByLanguage[mirror['language']]['mirrors'].append(mirror)

            self.mirrors = []
            self.groups = list(sorted(self.groups, key=lambda x: x['priority']))
            for group in self.groups:
                n = len(group['mirrors'])
                if n == 1:
                    group['caption'] += ' (%s Mirror)' % n
                else:
                    group['caption'] += ' (%s Mirrors)' % n
                group['mirrors'] = list(sorted(group['mirrors'], key=lambda m: -m['weight']))
                self.mirrors.extend(group['mirrors'])

            getHosters(self.params)
            self.streamSelect = self.getStreamSelect()
            if self.streamSelect == 'grouped':
                heading = 'Sprache w\xc3\xa4hlen'
                captions = [ mirror['caption'] for mirror in self.groups ]
            elif self.streamSelect == 'hosters':
                heading = 'Hoster w\xc3\xa4hlen'
                captions = [ mirror['caption'] for mirror in self.mirrors ]
            elif self.streamSelect == 'hosters2':
                heading = 'Hoster w\xc3\xa4hlen'
                captions = []
                for i, mirror in enumerate(self.mirrors):
                    mirror['caption'] = 'Mirror %s, %s' % (i + 1, mirror.get('name', mirror['hoster']))
                    mirror['short_caption'] = 'Mirror %s, %s' % (i + 1, mirror.get('name', mirror['hoster']))
                    captions.append(mirror['caption'])

            elif self.streamSelect != 'auto':
                raise RuntimeError('Invalid value for streamSelect: %s' % self.streamSelect)
            if self.streamSelect != 'auto':
                index = xbmcgui.Dialog().select(heading, captions)
                if index < 0:
                    return
            else:
                index = 0
            if self.streamSelect == 'grouped':
                self.mirrors = self.groups[index]['mirrors']
            elif self.streamSelect == 'hosters':
                mirror = self.mirrors[index]
                group = groupsByLanguage[mirror['language']]
                self.mirrors = group['mirrors'][group['mirrors'].index(mirror):]
            elif self.streamSelect == 'hosters2':
                self.mirrors = self.mirrors[index:]
            if self.streamSelect in ('hosters', 'hosters2') and not getAutoTryNextStream():
                self.mirrors = [
                 self.mirrors[0]]
            from urlresolver import load_external_plugins
            from urlresolver.resolver import ResolverError
            load_external_plugins()
            self.initProgress()
            try:
                try:
                    self.findMirror()
                except ValueError as e:
                    if e.message == 'CANCELED':
                        return
                    if e.message == 'FAILED':
                        self.showFailedNotification()
                        return
                    raise

            finally:
                if self.progress is not None:
                    self.progress.close()
                    self.progress = None

            return

    def showFailedNotification(self):
        xbmc.executebuiltin('Notification(%s,%s,%s,%s)' % (
         'VAVOO.TO',
         'Beim aufrufen des Streams ist ein Fehler aufgetreten',
         5000,
         utils.addon.getAddonInfo('icon')))

    def initProgress(self):
        self.progress = xbmcgui.DialogProgress()
        self.progress.create('VAVOO.TO', u'Der Stream wird gestartet...')

    def checkCanceled(self):
        if self.progress.iscanceled():
            raise ValueError('CANCELED')

    def setMirrorProgress(self, step, *args, **kwargs):
        STEPS_PER_MIRROR = 4
        current = step
        total = STEPS_PER_MIRROR
        self.progress.update(int(current * (100.0 / total)), *args, **kwargs)
        self.checkCanceled()

    def findMirror(self):
        prevMirror = None
        for self.mirrorIndex, mirror in enumerate(self.mirrors):
            if self.mirrorIndex == 0:
                lines = ('Die Wiedergabe wird gestartet.',
                 mirror.get('short_caption', mirror['caption']))
            else:
                lines = ('%s fehlgeschlagen.' % prevMirror.get('short_caption', mirror['caption']),
                 'Versuche %s...' % mirror.get('short_caption', mirror['caption']))
            self.setMirrorProgress(0, *lines)
            prevMirror = mirror
            self.checkCanceled()
            url = mirror['url']
            if url is None:
                continue
            url = url.replace('https://nullrefer.com/?', '')
            resolvedUrl = self.resolveUrl(mirror, url)
            if not resolvedUrl:
                continue
            self.setMirrorProgress(1)
            if self.tryMirror(mirror, url, resolvedUrl):
                return

        raise ValueError('FAILED')
        return

    def resolveUrl(self, mirror, url):
        xbmc.log('Resolving URL: %s' % url, xbmc.LOGWARNING)
        cacheKey = url
        originalUrl = url
        cachedUrl = None
        if cachedUrl:
            print 'Got resolved URL from cache: %s' % cachedUrl
            return cachedUrl
        else:
            url = self.resolveUrl1(mirror, originalUrl)
            xbmc.log('Resolve 1: %s' % url, xbmc.LOGWARNING)
            if not url:
                url = self.resolveUrl2(mirror, originalUrl)
                xbmc.log('Resolve 2: %s' % url, xbmc.LOGWARNING)
            if url:
                if xbmc.getCondVisibility('system.platform.android') and '.m3u8' in url:
                    xbmc.log('video not for android', xbmc.LOGERROR)
                    return
                utils.cache['short'].set(cacheKey, url)
                return url
            if url is False:
                print 'Reporting not working URL: %s' % url
            return

    def resolveUrl1(self, mirror, url):
        try:
            from urlresolver import resolve
            from urlresolver.resolver import ResolverError
            return resolve(url)
        except ResolverError:
            import traceback
            traceback.print_exc()
            return
        except Exception as e:
            import traceback
            traceback.print_exc()
            return

        return

    def resolveUrl2(self, mirror, url):
        try:
            res = callApi2('open', {'link': url})
            if not res:
                raise ValueError('no link')
            from urlresolver.plugins.lib import helpers
            return res[0]['url'] + helpers.append_headers(res[0].get('headers', {}))
        except Exception as e:
            import traceback
            traceback.print_exc()
            return

        return

    def tryMirror(self, mirror, url, resolvedUrl):
        print 'Trying resolved URL: %s' % resolvedUrl
        try:
            resolvedUrl = utils.fix_stream_url(resolvedUrl)
            o = createListItem(self.params, self.data, isPlayable=True)
            o.setPath(resolvedUrl)
            self.player.play(resolvedUrl, o)
            self.mirrorsTried += 1

            def infostr():
                try:
                    return 'step=%s, playing=%s, time=%s URL: %s' % (
                     step, self.player.isPlaying(),
                     self.player.isPlaying() and self.player.getTime(),
                     mirror['hoster'])
                except RuntimeError as e:
                    if e.message == 'XBMC is not playing any media file':
                        return 'XBMC is not playing any media file'
                    raise

            step = 1
            STEP_TIMEOUT = 45
            abortReason = ''
            t = time.time()
            try:
                sleep = 10
                while not abortReason:
                    print 'Player running: %s' % infostr()
                    if xbmc.abortRequested or self.progress and self.progress.iscanceled():
                        abortReason = 'canceled'
                    elif step == 1:
                        if self.player.isPlaying():
                            self.setMirrorProgress(2)
                            step = 2
                        elif time.time() - t > STEP_TIMEOUT:
                            abortReason = 'timeout'
                    elif step == 2:
                        if xbmc.getInfoLabel('VideoPlayer.VideoResolution'):
                            self.setMirrorProgress(3, line3='Viel Spa\xc3\x9f mit VAVOO!')
                            self.player.stop()
                            sleep = 100
                            step = 3
                        elif not self.player.isPlaying():
                            abortReason = 'died'
                    elif step == 3:
                        if not self.player.isPlaying():
                            xbmcplugin.setResolvedUrl(utils.getPluginhandle(), True, o)
                            t = time.time()
                            step = 4
                    elif step == 4:
                        if self.player.isPlaying():
                            self.setMirrorProgress(4)
                            step = 5
                        elif time.time() - t > STEP_TIMEOUT:
                            abortReason = 'timeout'
                    elif step == 5:
                        if not self.player.isPlaying():
                            abortReason = 'stopped'
                        elif self.player.getTime() > 0.0:
                            resolution = xbmc.getInfoLabel('VideoPlayer.VideoResolution')
                            if resolution:
                                self.setSuccessfulConnection(mirror['hoster'])
                                if self.progress is not None:
                                    self.progress.close()
                                    self.progress = None
                                sleep = 1000
                                step = 6
                    elif step == 6:
                        if not self.player.isPlaying():
                            abortReason = 'stopped'
                    else:
                        raise RuntimeError('Unknow step: %r' % step)
                    if not abortReason:
                        xbmc.sleep(sleep)

                print 'Player stopped: reason=%s, %s' % (abortReason, infostr())
            finally:
                self.player.stop()

            if abortReason in ('canceled', 'stopped'):
                return True
            if step >= 4:
                raise RuntimeError('Stream died! reason=%s, %s' % (abortReason, infostr()))
            return False
        except Exception as e:
            import traceback
            traceback.print_exc()
            return False

        return


def addDir(name, url, iconimage='DefaultFolder.png', isFolder=True, isPlayable=False):
    liz = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name})
    if isPlayable:
        liz.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=utils.getPluginhandle(), url=url, listitem=liz, isFolder=isFolder)


def addDir2(name_, icon_, action, **params):
    params['action'] = action
    addDir(name_, utils.getPluginUrl(params), getIcon(icon_))


def getIcon(name):
    return xbmc.translatePath('special://home/addons/' + utils.addonID + '/resources/' + name + '.png').decode('utf-8')


def callApi(action, params, method='GET', headers=None, **kwargs):
    xbmc.log('callApi req: %s' % json.dumps(params), xbmc.LOGDEBUG)
    if not headers:
        headers = dict()
    headers['auth-token'] = utils.getAuthSignature()
    resp = utils.getSession().request(method, (BASEURL + action), params=params, headers=headers, **kwargs)
    resp.raise_for_status()
    data = json.loads(resp.content)
    xbmc.log('callApi res: %s' % json.dumps(data), xbmc.LOGDEBUG)
    return data


def callApi2(action, params, **kwargs):
    res = callApi(action, params)
    while True:
        if type(res) is not dict or 'id' not in res or 'data' not in res:
            return res
        import requests
        session = requests.session()
        data = res['data']
        if type(data) is dict and data.get('type') == 'fetch':
            params = data['params']
            body = params.get('body')
            headers = params.get('headers')
            resp = session.request(params.get('method', 'GET').upper(), data['url'], headers={k:v[0] if type(v) in (list, tuple) else v for k, v in headers.items()} if headers else None, data=body.decode('base64') if body else None, allow_redirects=params.get('redirect', 'follow') == 'follow')
            headers = dict(resp.headers)
            resData = {'status': resp.status_code, 
               'url': resp.url, 
               'headers': headers, 
               'data': resp.content.encode('base64').replace('\n', '') if data['body'] else None}
            res = callApi('res', {'id': res['id']}, method='POST', json=resData)
        elif type(data) is dict and data.get('error'):
            raise ValueError(data['error'])
        else:
            return data

    return